plugins {
    id("lib-android")
}
